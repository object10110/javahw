create definer = root@localhost view employees_from_london as
select `e`.`FIRST_NAME`      AS `first_name`,
       `e`.`LAST_NAME`       AS `last_name`,
       `e`.`JOB_ID`          AS `job_id`,
       `e`.`DEPARTMENT_ID`   AS `department_id`,
       `d`.`DEPARTMENT_NAME` AS `department_name`
from ((`hw_db`.`employees` `e` join `hw_db`.`locations` `loc` on (`loc`.`CITY` like 'London'))
         join `hw_db`.`departments` `d`
              on (`e`.`DEPARTMENT_ID` = `d`.`DEPARTMENT_ID` and `d`.`LOCATION_ID` = `loc`.`LOCATION_ID`));

