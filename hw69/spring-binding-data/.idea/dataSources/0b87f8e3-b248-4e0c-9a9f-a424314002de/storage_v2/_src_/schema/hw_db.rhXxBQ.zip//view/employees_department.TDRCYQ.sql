create definer = root@localhost view employees_department as
select `e`.`FIRST_NAME` AS `first_name`, `e`.`LAST_NAME` AS `last_name`, `d`.`DEPARTMENT_NAME` AS `department_name`
from (`hw_db`.`employees` `e`
         join `hw_db`.`departments` `d` on (`e`.`DEPARTMENT_ID` = `d`.`DEPARTMENT_ID`));

