create definer = root@localhost view employees_department_location as
select `e`.`FIRST_NAME`      AS `first_name`,
       `e`.`LAST_NAME`       AS `last_name`,
       `d`.`DEPARTMENT_NAME` AS `department_name`,
       `loc`.`CITY`          AS `city`
from ((`hw_db`.`employees` `e` join `hw_db`.`locations` `loc`)
         join `hw_db`.`departments` `d`
              on (`e`.`DEPARTMENT_ID` = `d`.`DEPARTMENT_ID` and `d`.`LOCATION_ID` = `loc`.`LOCATION_ID`));

