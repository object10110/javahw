create definer = root@localhost view department_location as
select `dep`.`LOCATION_ID`    AS `location_id`,
       `loc`.`STREET_ADDRESS` AS `street_address`,
       `loc`.`CITY`           AS `city`,
       `loc`.`STATE_PROVINCE` AS `state_province`,
       `c`.`COUNTRY_NAME`     AS `country_name`
from ((`hw_db`.`departments` `dep` join `hw_db`.`locations` `loc` on (`loc`.`LOCATION_ID` = `dep`.`LOCATION_ID`))
         join `hw_db`.`countries` `c` on (`c`.`COUNTRY_ID` = `loc`.`COUNTRY_ID`));

