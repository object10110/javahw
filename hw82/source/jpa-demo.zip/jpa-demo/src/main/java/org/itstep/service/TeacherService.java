package org.itstep.service;

import org.itstep.service.dto.TeacherDto;

public interface TeacherService extends GenericService<TeacherDto> {
}
