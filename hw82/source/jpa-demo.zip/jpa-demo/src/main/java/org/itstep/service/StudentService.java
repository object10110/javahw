package org.itstep.service;

import org.itstep.service.dto.StudentDto;

public interface StudentService extends GenericService<StudentDto> {
}
