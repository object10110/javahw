-- use academy;
insert into students(
    first_name
    , last_name
    , age
    , "group"
    , birth_date
)
values('Вася'
    , 'Пупкин'
    , 21
    , 'ЕКО 19-П-1'
    , '2001-01-01'
);

insert into students(
    first_name
    , last_name
    , age
    , "group"
    , birth_date
)
values(
    'Маша'
    , 'Ефросинина'
    , 45
    , 'ЕКО 19-П-3'
    , '1998-10-12'
);