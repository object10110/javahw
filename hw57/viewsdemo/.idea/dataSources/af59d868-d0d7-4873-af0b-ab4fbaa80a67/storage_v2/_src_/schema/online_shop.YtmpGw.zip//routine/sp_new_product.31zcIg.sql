create
    definer = root@localhost procedure sp_new_product(IN supplier_id int, IN product_name varchar(50),
                                                      IN category_name varchar(50), IN net_retail_price decimal(10, 2),
                                                      IN available_quantity int, IN wholesale_price decimal(10, 2),
                                                      IN unit_kg_weight decimal(10, 5), OUT product_id int)
begin
    declare id int;
    select ProductCategoryID into id from productcategories where ProductCategoryName = category_name;
    case id when null then
        begin
            insert into productcategories(ProductCategoryName) values (category_name);
            set id = last_insert_id ();
        end;
        else
            set id = id;
    end case;
    insert into products(productcategoryid, supplierid, productname, netretailprice, availablequantity, wholesaleprice, unitkgweight)
      values (id, supplier_id, product_name, net_retail_price, available_quantity, wholesale_price, unit_kg_weight);
    set product_id = last_insert_id ();
end;

