create definer = root@localhost view pc_view as
select `online_shop`.`productcategories`.`ProductCategoryName` AS `Name`
from `online_shop`.`productcategories`;

