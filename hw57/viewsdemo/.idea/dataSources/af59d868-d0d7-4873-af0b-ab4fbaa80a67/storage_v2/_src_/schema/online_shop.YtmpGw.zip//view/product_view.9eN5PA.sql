create definer = root@localhost view product_view as
select `online_shop`.`products`.`ProductName`                  AS `Name`,
       `online_shop`.`productcategories`.`ProductCategoryName` AS `Category`
from (`online_shop`.`products`
         join `online_shop`.`productcategories` on (`online_shop`.`products`.`ProductCategoryID` =
                                                    `online_shop`.`productcategories`.`ProductCategoryID`));

