create
    definer = root@localhost procedure print_from_to(IN start_index int, IN end_index int)
begin
    declare `@amount` int;
    set `@amount` = end_index-start_index;

    select d.firstName DirectorFN, d.lastName DirectorLN
    from movies.director d
    limit `@amount` offset start_index;

    select m.Title, m.Rating
    from movies.movie m
    limit `@amount` offset start_index;

    select a.firstName ActorFN, a.lastName ActorLN
    from movies.actor a
    limit `@amount` offset start_index;

end;

