create
    definer = root@localhost procedure delete_director_without_films()
begin

    delete from movies.director
    where id not in (select distinct dd.id from movies.director dd
                       join movies.movie m on dd.id = m.directorId);

end;

