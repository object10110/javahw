create
    definer = root@localhost procedure change_genre(IN current_genre text, IN new_genre text)
begin
    update movies.genre g
    set g.name = new_genre
    where g.name LIKE(current_genre);
end;

