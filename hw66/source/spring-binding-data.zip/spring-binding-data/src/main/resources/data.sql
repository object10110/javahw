use academy;
insert into students(first_name, last_name, age, group)
values('Вася', 'Пупкин', 21, 'ЕКО 19-П-1');