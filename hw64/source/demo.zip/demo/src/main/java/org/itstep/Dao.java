package org.itstep;

public interface Dao<T> {
    void save(T data);
}
