package org.itstep;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.inject.Named;

@Component
public class StudentDao implements Dao<Student> {

    DataSource dataSource;

    @Inject // @Autowired <--> @Inject, @Qualifier <--> @Named
    public StudentDao(@Named("postgresDataSource") DataSource source) {
        System.out.println("Student created");
        this.dataSource = source;
    }

    public void save(Student data) {
        System.out.println("Save student " + data);
    }
}
