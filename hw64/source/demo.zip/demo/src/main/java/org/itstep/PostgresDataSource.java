package org.itstep;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.sql.Connection;

@Component
@Scope("prototype")
public class PostgresDataSource implements DataSource {
    public Connection getConnection() {
        return null;
    }

    public void setUrl(String url) {

    }

    public void setPassword(String password) {

    }

    public void setUser(String username) {

    }
}
