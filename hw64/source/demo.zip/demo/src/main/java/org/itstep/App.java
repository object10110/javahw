package org.itstep;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

    public static void main(String[] args) {
        ApplicationContext ctxt = new ClassPathXmlApplicationContext("spring-config.xml");
        StudentDao dao = ctxt.getBean(StudentDao.class);
        dao.save(new Student());

        StudentDao dao2 = ctxt.getBean(StudentDao.class);

        System.out.println(dao == dao2);
    }

}