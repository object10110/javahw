package org.itstep;

import java.sql.Connection;

interface DataSource {
    Connection getConnection();
    void setUrl(String url);
    void setPassword(String password);
    void setUser(String username);
}