package org.itstep;

import org.springframework.stereotype.Component;

import java.sql.Connection;

@Component
public class MysqlDataSource implements DataSource {
    public Connection getConnection() {
        return null;
    }

    public void setUrl(String url) {
        System.out.println("Set url: " + url);
    }

    public void setPassword(String password) {
        System.out.println("Set pass: " + password);
    }

    public void setUser(String username) {
        System.out.println("Set username: " + username);
    }
}
