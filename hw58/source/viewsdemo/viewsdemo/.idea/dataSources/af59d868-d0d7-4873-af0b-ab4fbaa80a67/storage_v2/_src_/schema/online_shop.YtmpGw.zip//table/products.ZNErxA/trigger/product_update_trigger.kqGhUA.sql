create definer = root@localhost trigger product_update_trigger
    before update
    on products
    for each row
begin
        insert into products_log(msg, product_id, `time`)
            values ('UPDATE', OLD.ProductID, current_timestamp());
    end;

